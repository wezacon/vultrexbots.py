# DBSL.py

A simple to use library for DBSL server listing.